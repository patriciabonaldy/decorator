import Vue from 'vue'
import Router from 'vue-router'
import Congrats from '@/components/Congratulation.vue'
import Home from '@/components/Home.vue'
import Error404 from '@/components/Error404.vue'

Vue.use(Router)

function load (component) {
  return () => import(`@/components/${component}.vue`)
}


export default new Router({
  routes: [
    {
      path: '/',
      name: 'Home',
      component: Home
    },
    { 
      path: '*',
      name: 'Página no encontrada',
      component: load('Error404'),
      meta: { noFeedback: true }
    },
    { 
      path: '/congrats',
      name: 'congrats',
      component: load('Congratulation'),
      meta: { noFeedback: true }
    }
  ]
})
