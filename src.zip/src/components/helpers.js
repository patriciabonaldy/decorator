/**
 * 
 * @param {*input value a validar} value 
 */
export function  mayorQcero(value){
  if(value=="")
      return true;
  value = value.replace("-", "");    
  return (parseInt(value) > 0 && !value.startsWith("0"));
}

export function  valorMaximoyMinimo(value){    
  return ((parseInt(value) > 0 && !value.startsWith("0")) || 
          (parseInt(value) < 101)
        );
}

export function  validatedTotalTransferencia(value1, value2){
  if(value2>100){
    let vTrns = 100 - (value2-value1);
    if(value1>100)
      return false;
  }
}

/**
 * 
 * @param {* palabra a buscar} word 
 * @param {* } map 
 */
export function buscarCuitEnMap(word, map){
  word = word.replace(new RegExp('-', 'g'), ''); 
  let i =0;
  let mapCuit = map.filter(x => {
    //return x.cuit.toLowerCase().includes(word.toLowerCase())
    return x.cuit == word
  });
  for (i in mapCuit)
    mapCuit[i].invalido = false
   return mapCuit; 
}

export function formatPrice(value){
  if(value=="NaN" ||value=="")
    return "0"
  let val = (value/1).toFixed(2).replace('.', ',')
    return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")
}


export function countInvalidadosInMap(map){
  let mapCount = map.filter(x => {
    return x.invalido == true
  });
   return mapCount.length; 
}
//TODO: REFACTORIZAR
/*
export function setCuitEnMap(type, cuit, map){
  if(cuit==undefined){
    map.push(cuit);
    if(type==1)
    this.addTransferente(this.usersFilter[0]);
  }  
}*/



