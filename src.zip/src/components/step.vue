<template>
	<div class="step-wrapper float-right" :class="stepWrapperClass">
		<button type="button" class="btn btn-link" @click="lastStep" :hidden="firststep">
			Volver
		</button>
		<button type="button" class="btn btn-primary" @click="nextStep" :hidden="laststep" :disabled="continuar">
			Continuar
		</button>
		<router-link  class="btn btn-primary" v-if="laststep" :to="'congrats'"  v-on:click.native="finalizar">
			Continuar
		</router-link>
	</div>
</template>
<script>
	import { mapState } from 'vuex';
	import { mapMutations } from 'vuex';

	export default {
		name:"step",
		props: ["step", "stepcount", "currentstep"],

		computed: {
			...mapState([
            'continuar', 'steps'
        	]),
			active() {
				return this.step.id == this.currentstep;
			},

			firststep() {
				return this.currentstep == 1;
			},

			laststep() {
				return this.currentstep == this.stepcount;
			},

			stepWrapperClass() {
				return {
					active: this.active
				};
			},
			getContinuar() {
				return this.$store.getters.continuar
			}

			
		},

		methods: {
			...mapMutations([
           		'setCurrentPage','setContinuar',
        	]),
			nextStep() {
				//this.setCurrentPage(this.currentstep);
				//this.$emit("step-change", this.currentstep + 1);
				if(this.getValidatedStep(this.currentstep-1)){
					this.setCurrentPage(this.currentstep);
					this.$emit("step-change", this.currentstep + 1);
				}
				/*if(!this.$store.getters.mapStep[this.currentstep].validate)
					this.setContinuar(true);*/	
			},

			lastStep() {
				this.setCurrentPage(this.currentstep);
				this.$emit("step-change", this.currentstep - 1);
				this.getValidatedStep(this.currentstep - 2);
			},

			finalizar(){
				this.setCurrentPage(4);
			},

			getValidatedStep(n) {
				let val = this.$store.getters.mapStep[n].validate;
				if(!val){
					this.setContinuar(true);
					return false;
				} else {
					this.setContinuar(false);
					return true;
				}
				//return val;
        	}
		}
	}
</script>
