<template>   
    <section>   
        <div class="row">
            <div class="col-md-1" >
                <i :class="'fa fa-user fa-2x'"></i>
            </div>
            <div class="col-md-11 mb-4" >
                <h4 aria-describedby="transferenteTitle" ><b>Identificaci&oacute;n</b></h4>
                <small id="transferenteTitle" class="form-text text-muted mb-4">Ingres&aacute; los datos de los transferentes.</small>
                <!--  -->
                <div class="card col-md-10 mx-3 mb-3 p-0" v-for="(user, index) in getListTransferentes" :key="user.cuit">
                    <!-- <tarjeta user="user" index = "index" transferenciaLabel="transferenciaLabel"/> -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-1 p-0 text-center">
                                <i class="text-primary fa fa-user fa-2x"></i>
                            </div>
                            <div class="col-md-6 p-0 align-middle">
                                <h6><b>{{ user.name }}</b>&nbsp;({{ user.cuit | toCuit }})&nbsp;&nbsp;</h6>
                            </div>
                            <div class="col-md-4">
                                <b-form-checkbox 
                                    :id="'check'+user.cuit"
                                    :value="user.cuit"
                                    unchecked-value=""
                                    v-model="responsable">
                                    <label class="h2color"> Establecer como principal  </label>
                                </b-form-checkbox>
                            </div>
                            <div class="col-md-1 p-0 text-center">
                            <b-button variant="inverted" class="tacho" @click="removeRow(index)">
                                <i class="fa fa-trash inverted"></i>
                            </b-button>
                            </div>  
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="h2color">{{titularidadLabel}}</label> 
                                <input type="number" 
                                    min="0" 
                                    v-model="user.titularidad" 
                                    @blur="valorMaximoyMinimo(user.titularidad)"
                                    style="width: 20%; color:black" 
                                    class="col-2 h2color p-0 text-black"> %
                            </div>
                            <ul class="text-alert" v-if="errorValores">
                                    <li v-if="errorValores">
                                    El valor de Titularidad debe estar entre 1 y 100
                                    </li>
                            </ul>
                            <div class="col-md-6 h2color">
                                <b-form-group label="Vendes toda tu parte?" class="inline" :id="'radio'+user.cuit">
                                    <b-form-radio-group  v-model="user.selected" name="radio" plain>
                                        <b-form-radio value="1">Si</b-form-radio>
                                        <b-form-radio value="2">No</b-form-radio>
                                    </b-form-radio-group>
                                </b-form-group>
                            </div>
                            <div class="col-md-6" v-if="user.selected == '2'">
                                <label class="h2color">{{transferenciaLabel}}</label>
                                <input type="number" min="0"
                                    class="col-2 h2color p-0 text-black" 
                                    v-model="user.transferencia"
                                    @blur="verificarTransferencia(index)"
                                    v-b-tooltip.hover :title=message> %
                            </div>
                            <div class="col-md-12 text-danger" style="display: none;" v-bind:id="'errorTransfer'+index">
                                {{errorTransferencia}}.
                            </div>
                        </div>
                    </div>
                </div>
                <!--  -->
                <b-form inline class="mx-4 mb-2" v-if="validated == 0 && validated2==0">
                    <label for="text-cuit"><b>CUIT/CUIL/CDI</b></label>&nbsp;&nbsp;
                    <b-input id="textCuit" 
                        type="text" 
                        name="textCuit" 
                        class="col-md-2 mb-2" 
                        placeholder="CUIT/CUIL/CDI"  
                        v-model.trim.lazy="$v.textCuit.$model"
                        :disabled="validated == 1"
                        v-mask="'99-99999999-9'"
                        :status="$v.textCuit.$error ? 'error' : null"
                        @blur="$v.textCuit.$touch()">
                    </b-input>
                    <b-button :variant="icon_btn1" 
                        class="ml-2"
                        @click="search" 
                        :disabled="validated == 1 && validated2==1">CONFIRMAR</b-button>
                </b-form>
                <ul class="text-alert" v-if="$v.textCuit.$error">
                        <li v-if="!$v.textCuit.minLength">
                        Debe tener 11 digitos.
                        </li>
                        <li v-if="!$v.textCuit.maxLength">
                        Debe tener 11 digitos.
                        </li>
                        <li v-if="!$v.textCuit.mayorQcero">
                        No debe comenzar con cero.
                        </li>
                </ul>
                <!--span class="alert alert-danger" v-if="!$v.buscador.minLength">Debe tener 11 digitos.</span>
                <span class="alert alert-danger" v-if="!$v.buscador.maxLength">Debe tener 11 digitos.</span>
                <span class="alert alert-danger" v-if="!$v.buscador.mayorQcero">No debe comenzar con cero.</span-->
                <div class="row" v-if="!validated == 0 || !validated2==0">
                    <div class="col-md-7"></div>
                    <div class="col-md-5" style="ceta-Leyenda">
                        <button type="button" 
                            class="btn" 
                            style="font-size: 12px;"
                            v-show="checkBtn"
                            @click="agregarTransferentes"
                            :disabled="validarBtnAgregar == 1 " 
                            :class="icon_btn2">
                        <b>AGREGAR TRANSFERENTE </b></button>
                    </div>
                </div> 
                <!-- <div class="card bg-warning mt-3" style="width: 603px;" v-show="validated2==1">                                              
                    <div class="card-body leyenda" >
                        <label class="h2colorText">{{message2}}</label>
                        <form class="form-inline">
                            <input class="form-control-sm col-sm-6">
                            <button type="button" class="btn btn-primary ml-2">CONFIRMAR</button>
                        </form>
                    </div>      
                </div>  
                <br/>   -->
                <div class="row ml-3" v-show="checkBtn">
                    <h5 class="text-secondary"><b>Porcentaje total del bien transferido {{total}}%</b></h5>
                </div>
            </div>
        </div>
    </section>
</template> 

<script>
  import { mapMutations } from 'vuex'
  import AwesomeMask from 'awesome-mask'
  import {mayorQcero, buscarCuitEnMap,countInvalidadosInMap, formatPrice} from './helpers.js'
  import resConsulta from '../data/users.json'

  import { minLength , maxLength, numeric, email } from 'vuelidate/lib/validators'


  export default {
    name: 'Resultado',
    data() {
      return {  
        message: "Del 100% del automotor, ¿qué porcentaje vas a transferir? recordá que no puedes superar tu porcentaje de titularidad",
        message2: "Te recordamos que al seleccionar a este adquiriente como emisor del certificado, será quien pueda realizar la consulta del mismo a traves del servicio."+
                    "A continuacion, indicanos el correo electrónico para que podamos informárselo.",
        errorTransferencia:"Porcentaje de Transferencia, no debe ser mayor al de Titularidad",
        textCuit: '', 
        usersFilter: [],
        validated:0,
        validated2:0,
        totalTransferencia:0,
        users: resConsulta,
        titularidadLabel:"Cuál es tu porcentaje de titularidad?",
        transferenciaLabel:"Del total del vehículo cuanto vendes?",
        selected : false,
        responsable : "",
        errorValores: false
      }
    },
    directives: {
        'mask': AwesomeMask
    },    
    created(){
            this.setContinuar(true);
        },
    validations: {
        textCuit: {    
            minLength: minLength(13), 
            maxLength: maxLength(13), 
            mayorQcero//: this.$helpers.mayorQcero(buscador)
        }
        
    },
    methods: {        
        stepChanged(step) {
            this.currentstep = step;
        },
        ...mapMutations([
            'addTransferente', 'removeTransferente', 'setContinuar', 'setValidateStep'
        ]),
        search(){
            if(this.textCuit!=""){
                this.usersFilter= buscarCuitEnMap(this.textCuit, this.users);
                if(this.usersFilter.length>0){
                    var userExist = buscarCuitEnMap(this.textCuit, 
                                    this.getListTransferentes);
                    if(userExist.length<1){
                        this.addTransferente(this.usersFilter[0]);
                    }                
                    this.validated=1;
                    this.textCuit="";
                }                
            }
            
        },
        removeRow(index){
            var accepted = confirm('¿Estas seguro que deseas eliminar este Transferente?');
            if(accepted) {
                this.removeTransferente(index);
                if(this.getListTransferentes.length==0){
                    this.validated=0;
                }                    
                this.setValidateStep(false);    
                this.setContinuar(true);  
            }   
                       
        },
        agregarTransferentes(){
            this.validated=0;
            this.validated2=0;
        },
        valorMaximoyMinimo(value){    
            if (parseInt(value) == 0  ||   parseInt(value) > 100 ){
                 this.errorValores= true;      
                 this.setValidateStep(false);   
                 this.setContinuar(true);        
            } else {
                this.errorValores= false;
                this.setValidateStep(true);
                this.setContinuar(false);
            }
        },
        verificarTransferencia: function(x){
            /*let index = this.mapuser[x].transferencia;
            let dup_array = this.mapuser.slice();
            dup_array.splice(x, 1);
            let totalSinActual= dup_array.reduce(
                                function(total, user){
                                    return parseInt(total) + parseInt(user.transferencia); 
                            },0);
            this.valorMaximo = 100-totalSinActual;
            if(index>100){
                if(index>this.valorMaximo){
                    this.isInvalido = true;
                }
            }*/
            
            if(parseInt(this.getListTransferentes[x].transferencia) > parseInt(this.getListTransferentes[x].titularidad)){
               this.getListTransferentes[x].invalido = true;
                document.getElementById("errorTransfer"+x).style.display = null;
            } else {
                this.getListTransferentes[x].invalido = false;
                document.getElementById("errorTransfer"+x).style.display ='none';
            }  
             
            let cantidad = countInvalidadosInMap(this.getListTransferentes);
            if(cantidad>0){
                this.setContinuar(true);
            } else {
                this.setContinuar(false);
            }              
                
        },
        getStateStep() {
            return this.$store.getters.mapStep[1].validate;
        },
        verificarTransferencia(){
            let i =0;
            for (; i<this.getListTransferentes.length; i++){
                if(this.getListTransferentes[i].titularidad==""||
                parseInt(this.getListTransferentes[i].titularidad)<=0||
                parseInt(this.getListTransferentes[i].titularidad)>100){
                    this.errorValores= true;
                    return false;
                }
                if(this.getListTransferentes[i].transferencia==""
                ||parseInt(this.getListTransferentes[i].transferencia)<=0||
                parseInt(this.getListTransferentes[i].transferencia)>100){
                    return false;
                }
            }
            return true;
        }
    },
    watch:{
        total : function(val){
            if(val<=0 || val>100 || !this.verificarTransferencia()){
                this.setValidateStep(false);
            } else {
                this.setValidateStep(true);
            }    
        },
        getValidatedStep: function(val){
            if(!val){
                this.setContinuar(true);
            } else {
                this.setContinuar(false);
            }
        }
    }, 
    computed:{
        icon_btn1(){
            return this.validated==0?"primary":"secondary";
        },
        icon_btn2(){
            return this.validated==1 && this.validated2==0?"btn-primary":"btn-secondary";
        },
        checkBtn(){
            let lengthUsers = this.getListTransferentes.length;
            return lengthUsers>0?true:false;
        },
        checkTransfer: function(value){
            return value;
        },        
        total: function(){
            this.totalTransferencia= this.getListTransferentes.reduce(
                function(total, user){
                    return parseInt(total) + parseInt(user.transferencia); 
                },0);
            if(isNaN(this.totalTransferencia)) 
                this.totalTransferencia =0;    
            return this.totalTransferencia;
        },        
        validarBtnAgregar: function(){
            this.validated2=this.totalTransferencia>=100?1:0;
            this.totalTransferencia==100?true:false;
            return this.validated2;
        }
        ,getListTransferentes() {
            return this.$store.getters.transferentes
        }

        ,getValidatedStep() {
            let val = this.$store.getters.mapStep[1].validate;
            if(!val){
                this.setContinuar(true);
            } else {
                this.setContinuar(false);
            }
            return val;
        }
        
        
    }
}
</script>
