<template>
  <div class="step-indicator row">
      <div v-for="step in steps" is="stepNavigationStep" :key="step.id" :step="step" :currentstep="currentstep">
      </div>
  </div>
</template>

<script>
  import stepNavigationStep from './stepNavigationStep.vue'
	export default {
    name:'stepNavigation',
		props: ["steps", "currentstep"],
    components:{
      stepNavigationStep
    }
  }
</script>