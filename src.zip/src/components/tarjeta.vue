<template>
    <section>
        <div>
            <!-- <b-card header="Card Header"
                    header-text-variant="white"
                    header-tag="header"
                    header-bg-variant="dark"
                    footer="Card Footer"
                    footer-tag="footer"
                    footer-bg-variant="success"
                    footer-border-variant="dark"
                    title="Title"
                    style="max-width: 20rem;"
            >
                <p class="card-text">Header and footers variants.</p>
            </b-card> -->
            <div class="card-body">
                <div class="row">
                    <div class="col-md-1 p-0 text-center">
                        <i class="text-primary fa fa-user fa-2x"></i>
                    </div>
                    <div class="col-md-6 p-0 align-middle">
                        <h6><b>{{user.name }}</b>({{ user.cuit | toCuit }})&nbsp;&nbsp;</h6>
                    </div>
                    <div class="col-md-4">
                        <b-form-checkbox 
                            :id="'check'+user.cuit"
                            :value="user.cuit"
                            unchecked-value=""
                            v-model="responsable">
                            <label class="h2color"> Establecer como principal  </label>
                        </b-form-checkbox>
                    </div>
                    <div class="col-md-1 p-0 text-center">
                    <b-button variant="inverted" class="tacho" @click="removeRow(index)">
                        <i class="fa fa-trash inverted"></i>
                    </b-button>
                    </div>  
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label class="h2color">{{titularidadLabel}}</label> 
                        <input type="number" 
                            :value="user.titularidad" 
                            class="col-2 h2color p-0 text-black"> %
                    </div>
                    <div class="col-md-6 h2color">
                        <b-form-group label="Vendes toda tu parte?" class="inline" :id="'radio'+user.cuit">
                            <b-form-radio-group  v-model="user.selected" name="radio">
                                <b-form-radio value="si">Si</b-form-radio>
                                <b-form-radio value="no">No</b-form-radio>
                            </b-form-radio-group>
                        </b-form-group>
                    </div>
                    <div class="col-md-6" v-if="user.selected == 'no'">
                        <label class="h2color">{{transferenciaLabel}}</label>
                        <input type="number"
                            class="col-2 h2color p-0 text-black" 
                            v-model="user.transferencia"
                            @blur="verificarTransferencia(index)"
                            v-b-tooltip.hover :title=message> %
                    </div>
                    <div class="alert alert-danger" style="display: none;" v-bind:id="'errorTransfer'+index">
                        {{errorTransferencia}}.
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    name:"tarjeta",
    props: ["user","index","titularidadLabel","transferenciaLabel"],
}
</script>

