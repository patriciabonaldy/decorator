<template>
    <section class="pl-3">
        <div class="row sv-1 mb-3">
            <div class="col-md-1 align-self-center">
                <i class="fa fa-car fa-2x text-primary"></i>
            </div>
            <div class="col-md-11" v-for="auto in this.automotor" :key="auto.dominio">
                <div class="row">
                    <div class="col-md-11">
                        <h6><strong>Datos del bien</strong></h6>
                    </div>
                    <div class="col-md-1">
                        <a @click="editRow(1)">
                        <i class="fa fa-edit text-primary float-right" ></i>
                        </a>
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-2">Tipo</div>   
                    <div class="col-md-2">
                        {{auto.tipo}}
                    </div>   
                    <div class="col-md-4">Modelo</div>   
                    <div class="col-md-4">
                        {{auto.modelo}}
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-2">Dominio</div>   
                    <div class="col-md-2">
                        {{auto.dominio}}
                    </div>   
                    <div class="col-md-4">Valuaci&oacute;n DNRPCP</div>   
                    <div class="col-md-4">
                        ${{auto.valuacion}}
                    </div>   
                </div>
                <div class="row mb-2">
                    <div class="col-md-2">A&ntilde;o</div>   
                    <div class="col-md-2">
                        {{auto.anio}}
                    </div>   
                    <div class="col-md-4">Valor total del bien a transferir</div>   
                    <div class="col-md-4">
                        ${{auto.valor }}
                    </div>   
                </div>
            </div>
        </div>
        <div class="row sv-1 mb-3">
            <div class="col-md-1 align-self-center">
                <i class="fa fa-users fa-2x text-primary"></i>
            </div>
            <div class="col-md-11">
                <div class="row">
                    <div class="col-md-11">
                        <h6><strong>Datos del transferente</strong></h6>
                    </div>
                    <div class="col-md-1">
                        <i class="fa fa-edit text-primary float-right" @click="editRow(2)"></i>
                    </div>
                </div>
                <div class="row mb-2" v-for="transferente in this.transferentes" :key="transferente.cuit">
                    <div class="col-md-4">
                        {{transferente.name}}
                    </div>
                    <div class="col-md-3">
                        ({{transferente.cuit | toCuit}})
                    </div>
                    <div class="col-md-5">Porcentaje de titularidad 
                        {{transferente.titularidad}}%
                    </div>  
                    <div class="col-md-5">Porcentaje de transferencia 
                        {{transferente.transferencia}}%
                    </div>  
                </div>
            </div>
        </div>
        <div class="row sv-1 mb-3">
            <div class="col-md-1 align-self-center">
                <i class="fa fa-users fa-2x text-primary"></i>
            </div>
            <div class="col-md-11" >
                <div class="row">
                    <div class="col-md-11">
                        <h6><strong>Datos del adquiriente</strong></h6>
                    </div>
                    <div class="col-md-1">
                        <i class="fa fa-edit text-primary float-right" @click="editRow(3)"></i>
                    </div>
                </div>
                <div class="row mb-2" v-for="adquiriente in this.adquirientes" :key="adquiriente.cuit">
                    <div class="col-md-4">{{adquiriente.name}}</div>  
                    <div class="col-md-3">({{adquiriente.cuit | toCuit }})</div>  
                    <div class="col-md-5">Porcentaje de titularidad {{adquiriente.transferencia}}%</div>  
                </div>
            </div>
        </div>
        <div class="row sv-1 mb-3">
            <div class="col-md-1 align-self-center">
                <i class="fa fa-user fa-2x text-primary"></i>
            </div>
            <div class="col-md-11">
                <div class="row">
                    <div class="col-md-11 mb-3">
                        <h6 aria-describedby="title-4" class=""><strong>Datos de contacto</strong></h6>
                        <small id="title-4" class="form-text text-muted">Record&aacute; que es necesario que ingreses tu correo electr&oacute;nico, ya que ah&iacute; se te enviar&aacute; el certificado.</small>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="inputEmail" class="col-md-4 text-right"><b>Correo electr&oacute;nico</b></label>
                    <div class="col-md-4">
                        <input type="text" class="form-control" id="inputEmail" v-model="email" 
                        :status="$v.email.$error ? 'error' : null" @blur="$v.email.$touch()">
                    </div>
                    <ul class="alert alert-danger" v-if="$v.email.$error">
                        <li v-if="!$v.email.required">
                        Este campo es requerido.
                        </li>
                        <li v-if="!$v.email.email">
                        Ingrese una direccion valida.
                        </li>
                    </ul>
                    
                </div>
            </div>
        </div>
        <div>
            <vue-recaptcha
            ref="recaptcha"
            @verify="onVerify"
            @expired="onExpired"
            :sitekey="sitekey">
            </vue-recaptcha>
            <button @click="resetRecaptcha"> Reset ReCAPTCHA </button>
        </div>
        
    </section>
</template>

<script>
import { mapState } from 'vuex';
import { mapMutations } from 'vuex';
import VueRecaptcha from 'vue-recaptcha';
import { email, required } from 'vuelidate/lib/validators';

export default {
    data(){
        return{
            email:"",
            editAutomotor:false,
            op1:true,
            sitekey: '6Le8rWkUAAAAAB8A0E25XzPX_OLhukEzdwCt7fv1',
            widgetId: 0
        }
    },
    validations: {
        email: {
            required,
            email,
        }                                       
    },
    components: {
        'vue-recaptcha': VueRecaptcha
    },
    computed: {
        ...mapState([
            'automotor',
            'transferentes',
            'adquirientes'
        ]),
    },
    methods:{
        ...mapMutations([
            'setCurrentstep'
        ]),
        editRow(step){
            this.setCurrentstep(step);
        },
        onSubmit: function () {
            this.$refs.invisibleRecaptcha.execute()
        },
        onVerify: function (response) {
            console.log('Verify: ' + response)
        },
        onExpired: function () {
            console.log('Expired')
        },
        resetRecaptcha () {
         this.$refs.recaptcha.reset() // Direct call reset method
        }
    }
}
</script>

<style>
    .sv-1{
        position: relative;
        padding: .75rem 1.25rem;
        background-color: #fff;
        border: 1px solid rgba(0,0,0,.125);
        border-left: 4px;
        border-left-style: solid;
        border-left-color: #50b5e2;
        margin-left: 10%;
        margin-right: 15%;
    }
</style>

