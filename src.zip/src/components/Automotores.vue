<template>
    <section>
        <div class="row mb-2">
            <div class="col-md-1">
                <i class="fa fa-car fa-2x"></i>
            </div>
            <div class="col-md-11 mb-4">
                <h4 aria-describedby="automotorTitle"><b>{{automotorTitle}}</b></h4>
                <small id="automotorTitle" class="form-text text-muted mb-4">{{automotorTitleSm}}</small>
                <b-form inline class="mx-4 mb-5">
                    <label ><b>Dominio</b></label>&nbsp;&nbsp;
                    <b-input type="text" class="col-md-2 mb-2" placeholder="Dominio" 
                    v-model="textDominio" :disabled="!editDominio"
                    id="textDominio"  name="textDominio" ></b-input>
                    <!--  /*v-mask="'AAA-9999'"    */-->
                    <b-button class="ml-2" v-if="editDominio"  variant="primary" @click="setMyAutomotor">CONFIRMAR</b-button>
                    <b-button class="ml-2" v-if="!editDominio" variant="primary" @click="clearMyAutomotor">MODIFICAR</b-button>
                </b-form>
                <!-- <div v-if="!editDominio && !editAutomotor">
                    <table role="table" aria-busy="false" aria-colcount="5" class="table b-table table-hover table-sm b-table-stacked-md">
                        <thead>
                            <tr>
                                <th tabindex="0" aria-colindex="1">Tipo</th>
                                <th tabindex="0" aria-colindex="3">Modelo</th>
                                <th tabindex="0" aria-colindex="4">A&ntilde;o</th>
                                <th tabindex="0" aria-colindex="5">Valuaci&oacute;n DNRPCP</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody role="rowgroup"> 
                            <tr aria-rowindex="1" role="row" v-for="(auto) in getListAutomotores" :key="auto.dominio">
                                <td aria-colindex="1" data-label="Tipo" role="cell" class="">
                                    {{auto.tipo}}
                                </td>
                                <td aria-colindex="3" data-label="Modelo" role="cell" class="">
                                    {{auto.modelo}}
                                </td>
                                <td aria-colindex="4" data-label="Año" role="cell" class="">
                                    {{auto.anio}}
                                </td>
                                <td aria-colindex="5" data-label="Valuación DNRPCP" role="cell" class="">
                                   $ {{auto.valuacion}} 
                                </td>
                                <td aria-colindex="6" data-label="edit" role="cell" class="" v-if="auto.dominio !=''">
                                    <i class="fa fa-edit text-primary" @click="editRow()"></i>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div> -->
                <div v-if="!editDominio && !editAutomotor">
                    <form v-for="(auto2) in getListAutomotores" :key="auto2.dominio" class="row">
                        <b-form-group label="<b>Tipo</b>" label-for="tipo" class="col-6">
                            <b-form-select id="tipo" :options="options" required v-model="auto2.tipo" style="height: 54px;">
                                <option :value="null">Seleccione un tipo</option>
                            </b-form-select>
                            <!-- <b-form-select v-model="automotor.tipo" :options="options" class="form-control-sm" aria-selected="automotor"/> -->
                        </b-form-group>
                        <b-form-group label="<b>Año</b>" label-for="anio" class="col-6" >
                            <b-form-input id="anio" type="text" v-model="auto2.anio" placeholder="Año">
                            <!-- <input v-model="automotor.anio" :readOnly="!editAutomotor" class="form-control-sm"> -->
                            </b-form-input>
                        </b-form-group>
                        <!-- <b-form-group class="col-2">
                            <i class="fa fa-edit text-primary pt-5" @click="editRow()"></i>
                        </b-form-group> -->
                        <b-form-group label="<b>Modelo</b>" label-for="modelo" class="col-12">
                            <b-form-input id="modelo" type="text" v-model="auto2.modelo" placeholder="Modelo">
                            <!-- <input v-model="automotor.modelo" class="form-control-sm"> -->
                            </b-form-input>
                        </b-form-group>
                        <b-form-group label="<b>Valuacion DNRPCP</b>" label-for="valuacion" class="col-12">
                            <b-form-input id="valuacion" type="text" min="0" v-model="auto2.valuacion" readOnly class="form-control-plaintext bg-transparent">
                                <!-- <input v-model="automotor.valuacion" class="form-control-plaintext" readOnly> -->
                            </b-form-input>
                        </b-form-group>
                    </form>
                </div>
            </div>
        </div>
        <div v-if="this.automotoresObj.length>0">
            <div class="row">
                <div class="col-1">
                    <i class="fa fa-file fa-2x"></i>
                </div>
                <div class="col-11">
                    <h4 aria-describedby="transferenciaTitle"><b>{{transferenciaTitle}}</b></h4>
                    <form>
                        <div class="form-group form-inline">
                            <label><b>{{inputValorLabel }}&nbsp;&nbsp;</b></label>
                            <b-form-input type="text" v-mask="'money'"  size="sm" class="col-2" 
                            v-model="valor"
                            ></b-form-input>
                        </div>
                        <b-form-checkbox plain 
                            value="true"
                            unchecked-value="false"
                            v-model="isTransferSeguro">
                            {{transferenciaCheck}}
                        </b-form-checkbox>
                    </form>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
    import { mapMutations } from 'vuex'
    import { mapState } from 'vuex'
    import AwesomeMask from 'awesome-mask'
    import resConsulta from '../data/automotores.json'
    import options from '../data/options.json'
    import Vuelidate from 'vuelidate'
    import {mayorQcero, buscarCuitEnMap,countInvalidadosInMap, formatPrice} from './helpers.js'

    

    export default {
        data(){
            return{
                automotorTitle: "Identificación",
                automotorTitleSm: "Ingresá el dominio del vehiculo para continuar",
                transferenciaTitle: "Datos de la transferencia",
                transferenciaCheck:"Transfiero el Vehiculo a una compañia de seguros",
                inputValorLabel:"Valor total del bien a transferir",
                textDominio:"",
                editDominio: true,
                editAutomotor:false,
                selected: null,
                options: options,
                automotores:resConsulta,
                automotoresObj: [], //TODO: ver como colocar esto sincrono
                valor:0,
                isTransferSeguro:false
            }
        },
        directives: {
            'mask': AwesomeMask
        },
        created(){
            this.setContinuar(true);
        },
        methods: {
            ...mapMutations([
                'clearAutomotor',
                'setAutomotor',
                'setContinuar',
                'setCurrentPage',
                'setValidateStep'
            ]),
            /*setContinuar(){
                if(this.automotoresObj.length!=0){
                    //setContinuar();
                    this.setContinuar(true);
                }
            },*/
            validarCampos(){
                this.automotoresObj[0] = this.$store.getters.automotor[0];
                if(this.automotoresObj[0].tipo=="NaN" ||this.automotoresObj[0].tipo==""){
                    return false;
                }
                if(this.automotoresObj[0].modelo=="NaN" ||this.automotoresObj[0].modelo==""){
                    return false;
                }
                if(this.automotoresObj[0].anio=="NaN" ||this.automotoresObj[0].anio==""){
                    return false;
                }
                if(this.automotoresObj[0].valor=="NaN" ||this.automotoresObj[0].valor==""|| parseFloat(this.automotoresObj[0].valor)<=0){
                    return false;
                }
                return true;
            },
            clearMyAutomotor(){
                this.setContinuar(true);                
                this.clearAutomotor(0);
                this.automotoresObj= [];
                this.textDominio = "";
                this.editDominio = true;
                this.editAutomotor = false;
                //this.searchAutomotor();
            },
            setMyAutomotor(){
                this.searchAutomotor();
                /*if(this.getListAutomotores.length>=1){
                    this.setContinuar(false);
                }*/
                
            },
            searchAutomotor(){
                this.clearAutomotor(0);
                if(this.textDominio!=""){
                    this.automotoresObj= this.automotores.filter(auto => {
                        this.editDominio = false;
                        return auto.dominio.toLowerCase()==this.textDominio.toLowerCase()
                    });
                    if(this.automotoresObj.length>0){
                        this.setAutomotor(this.automotoresObj[0]);
                        this.automotoresObj[0].valuacion = formatPrice(this.automotoresObj[0].valuacion);
                    } 
                }else {
                    this.editDominio = true;
                }
            },
            setCurrentPage(){
                setCurrentPage("Datos de el Automotor");
            },
            editRow(){
                this.editAutomotor = !this.editAutomotor;
            }
        },
        watch: {
            editAutomotor: function(val){
                if(!val){
                    this.clearAutomotor(0);
                    this.setAutomotor(this.automotoresObj[0]);
                }
            },
            valor: function(val){
                this.$store.getters.automotor[0].valor=val;
                if(this.getListAutomotores.length>=1 
                    && this.validarCampos()){
                    this.setContinuar(false);
                    this.setValidateStep(true);
                    
                } else {
                    this.setContinuar(true);
                    this.setValidateStep(false);
                }
            }
            ,isTransferSeguro: function(val){
                this.$store.getters.automotor[0].isTransferSeguro=val;
            }
        },
        computed:{
            setCurrentTPage(){
                setCurrentPage();
            }
            ,getListAutomotores() {
                return this.$store.getters.automotor
            }
            
        }
    }
</script>
