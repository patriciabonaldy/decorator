 <template>      
    <section>
        <div class="row">
            <div class="col-md-1 .col-md-2" >
                <i :class="'fa fa-user fa-2x'"></i>
            </div>
            <div class="col-sm-11 mb-4" >
                <h4 aria-describedby="title-3"><b>Identificaci&oacute;n</b></h4>
                <small id="title-3" class="form-text text-muted mb-4">Ingres&aacute; los datos de los adquirientes.</small>
                <!--  -->
                <div class="card col-md-10 mx-3 mb-3 p-0" v-for="(user, index) in geListAdquirientes" :key="user.cuit">
                    <!-- <tarjeta user="user" index = "index" transferenciaLabel="transferenciaLabel"/> -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-1 p-0 text-center">
                                <i class="text-primary fa fa-user fa-2x"></i>
                            </div>
                            <div class="col-md-10 p-0 align-middle">
                                <h6><b>{{ user.name }}</b>&nbsp;({{ user.cuit | toCuit }})&nbsp;&nbsp;</h6>
                            </div>
                            <div class="col-md-1 p-0 text-center">
                                <b-button variant="inverted" class="tacho" @click="removeRow(index)">
                                    <i class="fa fa-trash inverted"></i>
                                </b-button>
                            </div>  
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="h2color">{{titularidadLabel}}</label> 
                                <input type="number" 
                                    min="0" 
                                    v-model="user.adquirencia" 
                                    style="width: 20%; color:black" 
                                    class="col-2 h2color p-0 text-black"> %
                            </div>
                            <!-- <div class="col-md-6" v-if="user.selected == '2'">
                                <label class="h2color">{{transferenciaLabel}}</label>
                                <input type="number" min="0"
                                    class="col-2 h2color p-0 text-black" 
                                    v-model="user.transferencia"
                                    @blur="verificarTransferencia(index)"
                                    v-b-tooltip.hover :title=message> %
                            </div> -->
                            <!-- <div class="col-md-12 text-danger" style="display: none;" v-bind:id="'errorTransfer'+index">
                                {{errorTransferencia}}.
                            </div> -->
                        </div>
                    </div>
                </div>
                <!--  -->
                <b-form inline class="mx-4 mb-2" v-if="validated == 0 && validated2==0">
                    <label for="text-cuit"><b>CUIT/CUIL/CDI</b></label>&nbsp;&nbsp;
                    <b-input id="textCuit" 
                        type="text" 
                        name="textCuit" 
                        class="col-md-2 mb-2" 
                        placeholder="CUIT/CUIL/CDI"  
                        v-model.trim.lazy="$v.textCuit.$model"
                        :disabled="validated == 1"
                        v-mask="'99-99999999-9'"
                        :status="$v.textCuit.$error ? 'error' : null"
                        @blur="$v.textCuit.$touch()">
                    </b-input>
                    <b-button :variant="icon_btn1" 
                        class="ml-2"
                        @click="search" 
                        :disabled="validated == 1 && validated2==1">CONFIRMAR</b-button>
                </b-form>
                <ul class="text-alert" v-if="$v.textCuit.$error">
                    <li v-if="!$v.textCuit.minLength">
                        Debe tener 11 digitos.
                    </li>
                    <li v-if="!$v.textCuit.maxLength">
                        Debe tener 11 digitos.
                    </li>
                    <li v-if="!$v.textCuit.mayorQcero">
                        No debe comenzar con cero.
                    </li>
                </ul>
                <div class="row" v-if="!validated == 0 || !validated2==0">
                    <div class="col-md-7"></div>
                    <div class="col-md-5" style="ceta-Leyenda">
                        <button type="button" 
                            class="btn" 
                            style="font-size: 12px;"
                            v-show="checkBtn"
                            @click="agregarTransferentes"
                            :disabled="validarBtnAgregar == 1 " 
                            :class="icon_btn2">
                        <b>AGREGAR ADQUIRIENTE </b></button>
                    </div>
                </div>
                <ul class="text-alert" v-show="errorValor">
                    <li >
                    El valor total de adquisicion no puede ser mayor al de transferencia.
                    </li>
                </ul>
                <div class="row ml-3" v-show="checkBtn">
                    <h5 class="text-secondary"><b>Porcentaje total del bien adquirido {{total}}%</b></h5>
                </div>
            </div>
        </div>
    </section>
</template> 

<script>
    import { mapState } from 'vuex'
    import { mapMutations } from 'vuex'
    import AwesomeMask from 'awesome-mask'
    import {mayorQcero, buscarCuitEnMap,countInvalidadosInMap} from './helpers.js'
    import resConsulta from '../data/users.json'

    import { minLength , maxLength, numeric, email } from 'vuelidate/lib/validators'

    export default {
        name: 'Resultado',
        data() {
            return {  
                message: "Del 100% del automotor, ¿qué porcentaje vas a adquirir? recordá que no puedes superar tu porcentaje de titularidad",
                message2: "Te recordamos que al seleccionar a este adquiriente como emisor del certificado, será quien pueda realizar la consulta del mismo a traves del servicio."+
                            "A continuacion, indicanos el correo electrónico para que podamos informárselo.",
                errorTransferencia:"Porcentaje de Adquirencia, no debe ser mayor al porcentaje de total del Transferencia",
                titularidadLabel:"Porcentaje de Adquirencia",
                textCuit: '',
                buscador: '', 
                usersFilter: [],
                validated:0,
                validated2:0,
                totalTransferencia:0,
                users: resConsulta,
                valorMaximo: 0    ,
                errorValor: false,
                itemUser: []    
            }
        },
        directives: {
            'mask': AwesomeMask
        },   
        created(){
            this.setContinuar(true);
        },
        validations: {
            textCuit: {    
                minLength: minLength(13), 
                maxLength: maxLength(13), 
                mayorQcero//: this.$helpers.mayorQcero(buscador)
            }
        },
        methods: {        
            stepChanged(step) {
                this.currentstep = step;
            },
            ...mapMutations([
                'addAdquiriente', 'removeAdquiriente', 'setContinuar', 'setValidateStep'
            ]),
            search(){
                if(this.textCuit!=""){
                    this.usersFilter= buscarCuitEnMap(this.textCuit, this.users);
                    if(this.usersFilter.length>0){
                        var userExist = buscarCuitEnMap(this.textCuit, 
                                        this.geListAdquirientes);
                        if(userExist.length<1){
                            this.addAdquiriente(this.usersFilter[0]);
                        }                
                        this.validated=1;
                        this.textCuit="";
                    }                
                }
            },
            removeRow(index){
                var accepted = confirm('¿Estas seguro que deseas eliminar este Transferente?');
                if(accepted) {
                    this.removeAdquiriente(index);
                    if(this.geListAdquirientes.length==0)
                        this.validated=0;
                }    
                this.setContinuar(true);            
            },
            agregarTransferentes(){
                this.validated=0;
                this.validated2=0;
            },
            verificarAdquirencia: function(x){
            if(this.geListAdquirientes[x].transferencia > this.geListAdquirientes[x].titularidad){
               this.geListAdquirientes[x].invalido = true;
                document.getElementById("errorTransfer"+x).style.display = null;
            } else {
                this.geListAdquirientes[x].invalido = false;
                document.getElementById("errorTransfer"+x).style.display ='none';
            }  
            let cantidad = countInvalidadosInMap(this.geListAdquirientes);
            if(cantidad>0){
                this.setContinuar(true);
                this.setValidateStep(false);   
            } else {
                this.setContinuar(false);
                this.setValidateStep(true);   
            }              
                
        }
        },
        computed:{
            ...mapState([
                'transferentes'
            ]),
            icon_btn1(){
                return this.validated==0?"btn-primary":"btn-secondary";
            },
            icon_btn2(){
                return this.validated==1 && this.validated2==0?"btn-primary":"btn-secondary";
            },
            checkBtn(){
                let lengthUsers = this.geListAdquirientes.length;
                return lengthUsers>0?true:false;
            },
            checkTransfer: function(value){
                return value;
            },  
            totalTransferente: function(){
                return this.getListTransferentes.reduce(
                    function(total, user){
                        return parseInt(total) + parseInt(user.transferencia); 
                    },0);
            },      
            total: function(){
                this.totalTransferencia= this.geListAdquirientes.reduce(
                    function(total, user){
                        return parseInt(total) + parseInt(user.adquirencia); 
                    },0);
                    this.errorValor= false;
                if(isNaN(this.totalTransferencia)) 
                    this.totalTransferencia =0;   
                if(this.totalTransferencia<=0 || this.totalTransferencia>100){
                    this.setContinuar(true);
                    this.setValidateStep(false);   
                } else if(this.totalTransferente!=this.totalTransferencia){
                    this.setContinuar(true);
                    this.setValidateStep(false);  
                    this.errorValor=true;
                } else {
                    this.setContinuar(false);
                    this.setValidateStep(true);   
                }      
                return this.totalTransferencia;
            },        
            validarBtnAgregar: function(){
                this.validated2=this.totalTransferencia>=100?1:0;
                this.totalTransferencia==100?true:false;
                return this.validated2;
            },
            geListAdquirientes() {
                return this.$store.getters.adquirientes
            }
            ,getListTransferentes() {
            return this.$store.getters.transferentes
        }
        }
	}
</script>


