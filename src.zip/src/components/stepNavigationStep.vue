 <template>
    <div :class="indicatorclass" class="step_sv col-md-3">
        <button class="step" @click="edit(step.id)"
		:disabled="getContinuar"><i v-if="step.icon_class" :class="step.icon_class"
		></i>{{step.icon_class?"":this.step.id}}</button>
        <div class="caption hidden-xs hidden-sm"><span v-text="step.title"></span></div>
    </div>
</template>

<script>
	import { mapMutations } from 'vuex';

	export default {
        name:"stepNavigationStep",
		props: ["step", "currentstep"],
	
		computed: {
			indicatorclass() {
				return {
					active: this.step.id == this.currentstep,
					complete: this.currentstep > this.step.id
				};
			},
			getContinuar() {
				return this.$store.getters.continuar
			}
		},
		methods:{
			...mapMutations([
				'setCurrentstep',
				'setContinuar'
        	]),
			edit(step){
				this.setCurrentstep(step);
        	}
		}
	}
</script>