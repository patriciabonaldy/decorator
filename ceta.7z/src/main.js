// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store';
import BootstrapVue from 'bootstrap-vue'
import Vuex from 'vuex'

import './assets/css/poncho.min.css'
import './assets/css/roboto-fontface.css'
import 'font-awesome/css/font-awesome.min.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
import './assets/css/ceta.css'
import 'es6-promise/auto'
import Vuelidate from 'vuelidate'
Vue.use(Vuelidate);
Vue.use(BootstrapVue);
Vue.use(Vuex)

Vue.config.productionTip = false  

Vue.filter('toCuit', function (value) {
  var s2 = (""+value).replace(/\D/g, '');
  var m = s2.match(/^(\d{2})(\d{8})(\d{1})$/);
  return (!m) ? null :m[1] + "-" + m[2] + "-" + m[3];
});


/* eslint-disable no-new */
/* eslint-disable eslint-plugin-vue */
new Vue({
  el: '#app',
  data:  {sitekey: '6Le8rWkUAAAAAB8A0E25XzPX_OLhukEzdwCt7fv1',
          widgetId: 0},
  router,
  store,
  components: {
    App
  },
  template: '<App/>'
})
