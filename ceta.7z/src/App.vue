<template>
    <b-container id="app"> 
      <b-nav class="md mb-2 bg-white">
        <div class="img-wrapper">
          <a href="http://www.afip.gob.ar/sitio/externos/" class="d-flex">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 174 60" width="174" height="60">
              <path d="M23 8L33 8C34 8 35 9 35 10L40 22 27 50C27 51 27 52 26 52L4 52C3 52 2 51 2 50L21 10C22 9 22 8 23 8Z" style="fill: none; stroke-linejoin: bevel; stroke-width: 3; stroke: rgb(22, 117, 169);"></path>
              <path d="M30 45L46 45C48 45 49 43 48 40L40 21" style="fill: none; stroke-linejoin: bevel; stroke-width: 3; stroke: rgb(22, 117, 169);"></path>
              <path d="M56 8L75 8C76 8 77 9 77 10L77 42C77 43 76 44 75 44L56 44C55 44 54 43 54 42L54 10C54 9 55 8 56 8Z" style="fill: none; stroke-linejoin: bevel; stroke-width: 3; stroke: rgb(22, 117, 169);"></path>
              <path d="M74 8L93 8C95 8 94 9 94 10L84 32C84 33 83 33 82 33L77 33" style="fill: none; stroke-linejoin: bevel; stroke-width: 3; stroke: rgb(22, 117, 169);"></path>
              <line x1="76" y1="21" x2="90" y2="21" style="fill: none; stroke-linejoin: bevel; stroke-width: 3; stroke: rgb(22, 117, 169);"></line>
              <path d="M102 8L121 8C121 8 122 9 122 10L122 42C122 43 121 44 121 44L102 44C101 44 100 43 100 42L100 10C100 9 101 8 102 8Z" style="fill: none; stroke-linejoin: bevel; stroke-width: 3; stroke: rgb(22, 117, 169);"></path>
              <path d="M130 8L149 8C150 8 150 9 150 10L150 42C150 43 150 44 149 44L130 44C129 44 128 43 128 42L128 10C128 9 129 8 130 8Z" style="fill: none; stroke-linejoin: bevel; stroke-width: 3; stroke: rgb(22, 117, 169);"></path>
              <path d="M147 8L170 8C172 8 172 10 172 10L163 32C162 33 161 34 160 34L151 34" style="fill: none; stroke-linejoin: bevel; stroke-width: 3; stroke: rgb(22, 117, 169);"></path>
            </svg>
          </a>
        </div>
        <b-nav-item class="mb-0 align-self-end">
          <h6>CETA</h6>
        </b-nav-item>
      </b-nav>
      <h6 class="ml-2">AFIP / CETA / {{currentPages[currentPage].title}}</h6>
      <router-view/> 
    </b-container>
</template>

<script>
import { navbar } from 'bootstrap-vue/es/components'
import { mapState } from 'vuex';

export default {
  
  name: 'App',
  data() {
    return {
      currentPages:[{
        id:0,
        title: "Datos del automotor"
      },
      {
        id:1,
        title: "Datos de los transferentes"
      },
      {
        id:2,
        title: "Datos de los adquirientes"
      },
      {
        id:3,
        title: "Emisión del certificado"
      },
      {
        id:4,
        title: "Finalización del trámite"
      }]
    }     
  },
  computed:{
    ...mapState([
      'currentPage'
    ]),
  }
}
</script>
