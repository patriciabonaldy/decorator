<template>
  <b-card id="card-aviso" class="b-inline-block px-3">
    <div class="row">
      <div  class="col-md-2 text-center">
        <i id="aviso-icono" class="fa fa-check-circle text-success"></i>
      </div>
      <div class="col-md-10">
        <div class="panel">
          <div class="panel-heading">
            <h4 ><b>Felicitaciones, concluiste el tr&aacute;mite y ya tenes tu certificado</b></h4>
            <h6 class="mb-4 text-muted">Record&aacute; que el mismo ya fue al mail que informaste oportunamente</h6>
          </div>
          <hr style="border-top:2px solid rgba(0,0,0,.1)">
          <div class="panel-body row">
            <div class="col-md-8">
              <p class="mb-4 text-muted text-justify">Ahora pod&eacute;s descargarlo o imprimirlo para entregarlo en la Direcci&oacute;n Nacional 
              de los Registros Nacionales de la Propiedad del Automotor y de Cr&eacute;ditos Prendarios (DNRPA)</p>
            </div>
            <div class="col-md-2">
              <img src="../assets/img/certificado-ejemplo.jpg" class="img-fluid" alt="Responsive image">
            </div>
            <div class="col-md-2">
              <div class="row mb-4">
                <i class="fa fa-download fa-2x"></i>
              </div>
              <div class="row mb-4">
                <i class="fa fa-print fa-2x"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </b-card>
</template>

<script>
  export default {
    name : 'Congratulation',
    data(){
      return{
        stepname:"Finalización del Trámite"
      }
    }
  } 
</script>

<style>
  #aviso-icono {
    font-size: 6rem;
  }

  #card-aviso{
    margin-top: 5%;
    margin-right: 15%;
    margin-left: 15%;
    margin-left: 15%;
  }
</style>