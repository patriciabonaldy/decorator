<template>
  <div class="text-center">
      <b-card class="d-inline-block px-3 mb-4">
        <div id="aviso-error" class="text-muted">
          <i class="fa fa-map-signs"></i> 404
        </div>
        <h5>Página no encontrada</h5>
        <div class="mb-4 text-muted">Al parecer hubo un error o no encontramos la página que estás buscando</div>
        <b-button variant="primary" to="/" block exact>Volver al inicio</b-button>
      </b-card>
      <div>
        <p class="small text-muted">
          ¿Creés que esta página debería existir u ocurrió algún problema inesperado?<br/>
          Sí es así, te pedimos que te comuniques con nuestro canal de Consultas Web para ayudarte
        </p>
        <b-button variant="outline-info" target="_blank" href="http://www.afip.gob.ar/consultas/">
          <i class="fas fa-comments"></i> Consultas Web
        </b-button>
      </div>
  </div>
</template>

<style>
  #aviso-error {
    font-size: 6rem;
  }
</style>