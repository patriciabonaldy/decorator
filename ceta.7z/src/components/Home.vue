<template>
  <section class="pt-2 ml-3 mr-3">
    <b-card>     
        <h4 aria-describedby="title-home"><b>CETA - Certificado de transferencia del automotor</b></h4>
        <small id="title-home" class="form-text text-muted">Obten&eacute; el certificado de la venta de tu auto en simples pasos.</small>
    </b-card>
      <stepNavigation :steps="steps" :currentstep="currentstep">
      </stepNavigation>
      <div v-show="currentstep == 1">
          <Automotores/>
      </div>
      <div v-show="currentstep == 2">
        <Transferentes/>
      </div>
      <div v-show="currentstep == 3">
          <Adquirientes/>
      </div>
      <div v-show="currentstep == 4">
          <Confirmacion/>
      </div>
      <step v-for="step in steps" :currentstep="currentstep" :key="step.id" :step="step" :stepcount="steps.length" @step-change="stepChanged">
      </step>
  </section>
</template>

<script>  
  import Automotores from './Automotores.vue'
  import Transferentes from './Transferentes.vue'
  import Adquirientes from './Adquirientes.vue'
  import Confirmacion from './Confirmacion.vue'
  import step from './step.vue'
  import stepNavigation from './stepNavigation.vue'
  import { mapState } from 'vuex'
  import { mapMutations } from 'vuex'

  export default {
    components:{
      stepNavigation,
      step,
      Automotores,
      Transferentes,
      Adquirientes,
      Confirmacion
    },
	  data() {
      return{
      }
    },
    computed: {
      ...mapState([
          'currentstep',
          'steps'
      ]),
      getContinuar() {
        return this.$store.getters.continuar
      }
    },
		methods: {
      ...mapMutations([
        'setCurrentstep'
      ]),
      setMyAutomotor(){
        this.search();
        this.setAutomotor(this.automotoresObj[0]);
        this.enabledDominio = false;
      },
			stepChanged(step) {
      if(!this.getContinuar)
				  this.setCurrentstep(step);
			}
		}
	}
</script>