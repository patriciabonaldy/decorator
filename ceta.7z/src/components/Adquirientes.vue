 <template>      
    <section>
            <div class="row">
                <div class="col-md-1 .col-md-2" >
                    <i :class="'fa fa-user fa-2x'"></i>
                </div>
                <div class="col-sm-11 mb-4" >
                    <h4 aria-describedby="title-3"><b>Identificaci&oacute;n</b></h4>
                <small id="title-3" class="form-text text-muted mb-4">Ingres&aacute; los datos de los adquirientes.</small>
                <form class="form-inline mx-4 mb-5">
                    <div class="form-group">
                        <label for="text-cuil"><b>CUIT/CUIL/CDI</b></label>&nbsp;&nbsp;
                        <input id="text-cuil" type="text" class="form-control-sm col-6" v-model.trim.lazy="$v.buscador.$model" :disabled="validated == 1" v-mask="'99-99999999-9'" >
                        <span class="alert alert-danger" v-if="!$v.buscador.minLength">Debe tener 11 digitos.</span>
                        <span class="alert alert-danger" v-if="!$v.buscador.maxLength">Debe tener 11 digitos.</span>
                        <span class="alert alert-danger" v-if="!$v.buscador.mayorQcero">No debe comenzar con cero.</span>
                    </div>
		    <button type="button" :class="icon_btn1" class="btn" @click="search" :disabled="validated == 1 && validated2==1" style="font-size: 12px;">CONFIRMAR</button>
                </form>	
            <!-- </div> 
            <div class="row" v-show="validated2 ==  0">
                <div class="col-sm-3"></div>
                <div class="col-sm-6 mb-3">
                    <button type="button"  :class="icon_btn1" class="btn" @click="search" :disabled="validated == 1 && validated2==1" style="font-size: 12px;">CONFIRMAR</button>
                </div>
            </div> -->
                    <div class="card col-md-6 mx-3 mb-3 pl-0" v-for="(user, index) in this.geListAdquirientes" :key="user.cuit" >
                        <div class="card-body">
                                <div class="row">
                                    <div class="col-md-1 align-self-center">
                                        <i class="text-primary thumbnail fa fa-user fa-2x"></i>
                                    </div>
                                    <div class="col-md-10">
                                        <h6 ><b>{{ user.name }}</b>  
                                            ({{ user.cuit | toCuit }})                                        
                                        </h6>
                                        <div class="h2color" >
                                            <label class="h2color">  Porcentaje de Adquirencia  </label>
                                            <input type="text" style="width: 5%; color:black" 
                                            class="h2color" v-model="user.adquirencia"
                                            v-b-tooltip.hover :title=message> %
                                            <br>
                                            
                                        </div>  
                                    </div>
                                    <div class="col-md-1">
                                        <button type="button" class="btn tacho mr-5" @click="removeRow(index)">
                                            <i class="fa fa-trash fa-1x inverted"></i>
                                        </button>
                                </div>
                            </div>  
                        </div>     
                    </div>
                </div>
            </div>
            <div class="row" style="margin-left: 407px; ceta-Leyenda">
                <button type="button" class="btn" 
                style="font-size: 12px;"  v-show="checkBtn" @click="agregarTransferentes"
                :disabled="validarBtnAgregar == 1 " :class="icon_btn2">
                <b>AGREGAR ADQUIRIENTE </b></button>
            </div>  
            <br/>  
            <div class="row h2colorText" style="margin-left: 105px; font-size: 16px;"  v-show="checkBtn">
                <b>Porcentaje total del bien adquirido {{total}}%</b>
            </div>      
         </section>
</template> 



<script>
  import { mapMutations } from 'vuex'
  import AwesomeMask from 'awesome-mask'
  import {mayorQcero, buscarCuitEnMap,countInvalidadosInMap} from './helpers.js'
  import resConsulta from '../data/users.json'

  import { minLength , maxLength, numeric, email } from 'vuelidate/lib/validators'

  export default {
     name: 'Resultado',
	data() {
      return {  
        message: "Del 100% del automotor, ¿qué porcentaje vas a adquirir? recordá que no puedes superar tu porcentaje de titularidad",
        message2: "Te recordamos que al seleccionar a este adquiriente como emisor del certificado, será quien pueda realizar la consulta del mismo a traves del servicio."+
                    "A continuacion, indicanos el correo electrónico para que podamos informárselo.",
        
        buscador: '', 
        usersFilter: [],
        validated:0,
        validated2:0,
        totalTransferencia:0,
        users: resConsulta,
        valorMaximo: 0    ,
        itemUser: []    
      }
    },
    directives: {
        'mask': AwesomeMask
    },    
    validations: {
        buscador: {    
            minLength: minLength(13), 
            maxLength: maxLength(13), 
            mayorQcero//: this.$helpers.mayorQcero(buscador)
        }
    },
    methods: {        
        stepChanged(step) {
            this.currentstep = step;
        },
        ...mapMutations([
             'addAdquiriente', 'removeAdquiriente', 'setContinuar'
        ]),
        search(){
            if(this.buscador!=""){
                this.usersFilter= buscarCuitEnMap(this.buscador, this.users);
                if(this.usersFilter.length>0){
                    var userExist = buscarCuitEnMap(this.buscador, 
                                    this.geListAdquirientes);
                    if(userExist.length<1){
                        this.addAdquiriente(this.usersFilter[0]);
                    }                
                    this.validated=1;
                    this.buscador="";
                }                
            }
            
        },
        removeRow(index){
            var accepted = confirm('¿Estas seguro que deseas eliminar este Transferente?');
            if(accepted) {
                this.removeAdquiriente(index);
                if(this.geListAdquirientes.length==0)
                    this.validated=0;
            }                
        },
        agregarTransferentes(){
            this.validated=0;
            this.validated2=0;
        }
        
    },
    
    computed:{
        icon_btn1(){
            return this.validated==0?"btn-primary":"btn-secondary";
        },
        icon_btn2(){
            return this.validated==1 && this.validated2==0?"btn-primary":"btn-secondary";
        },
        checkBtn(){
            let lengthUsers = this.geListAdquirientes.length;
            return lengthUsers>0?true:false;
        },
        checkTransfer: function(value){
            return value;
        },        
        total: function(){
            this.totalTransferencia= this.geListAdquirientes.reduce(
                function(total, user){
                    return parseInt(total) + parseInt(user.adquirencia); 
                },0);
            return this.totalTransferencia;
        },        
        validarBtnAgregar: function(){
            this.validated2=this.totalTransferencia>=100?1:0;
            this.totalTransferencia==100?true:false;
            return this.validated2;
        }
        ,geListAdquirientes() {
            return this.$store.getters.adquirientes
        }
        
        
    }
	}
</script>


