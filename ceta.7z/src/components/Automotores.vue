<template>
    <section>
        <div class="row mb-3">
            <div class="col-md-1">
                <i class="fa fa-car fa-2x"></i>
            </div>
            <div class="col-md-11 mb-4">
                <h4 aria-describedby="title-1"><b>Identificaci&oacute;n</b></h4>
                <small id="title-1" class="form-text text-muted mb-4">Ingres&aacute; la patente del vehiculo para continuar</small>
                <form class="form-inline mx-4 mb-2">
                    <div class="form-group">
                        <label for="dominio"><b>Dominio</b></label>&nbsp;&nbsp;
                        <input id="dominio" type="text" name="dominio" class="form-control-sm col-md-6 mb-2" placeholder="Dominio"  v-model="dominio" >
                            <!--  /*v-mask="'AAA-9999'"    */-->
                    </div>
                    <button type="button" class="btn btn-primary btn-sm" @click="setMyAutomotor">CONFIRMAR</button>
                </form>
            </div>
        </div>
        <div class="row mb-5">
            <div class="col-1">                
                <i class="fa fa-car fa-2x"></i>                
            </div>
            <div class="col-11">
                <h4 aria-describedby="title-1"><b>Detalles</b></h4>
                <table role="table" aria-busy="false" aria-colcount="5" class="table b-table table-hover table-sm b-table-stacked-md">
                    <thead>
                        <tr>
                            <th tabindex="0" aria-colindex="1">Tipo</th>
                            <th tabindex="0" aria-colindex="2">Dominio</th>
                            <th tabindex="0" aria-colindex="3">Modelo</th>
                            <th tabindex="0" aria-colindex="4">A&ntilde;o</th>
                            <th tabindex="0" aria-colindex="5">Valuaci&oacute;n DNRPCP</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody role="rowgroup" v-if="!editAutomotor"> 
                        <tr aria-rowindex="1" role="row" v-for="(automotor) in automotoresObj" :key="automotor.dominio">
                            <td aria-colindex="1" data-label="Tipo" role="cell" class="">
                                {{automotor.tipo}}
                            </td>
                            <td aria-colindex="2" data-label="Dominio" role="cell" class="" >
                                {{automotor.dominio}}
                            </td>
                            <td aria-colindex="3" data-label="Modelo" role="cell" class="">
                                {{automotor.modelo}}
                            </td>
                            <td aria-colindex="4" data-label="A&ntilde;o" role="cell" class="">
                                {{automotor.anio}}
                            </td>
                            <td aria-colindex="5" data-label="Valuaci&oacute;n DNRPCP" role="cell" class="">
                                {{automotor.valuacion}}
                            </td>
                            <td aria-colindex="6" data-label="edit" role="cell" class="" v-if="automotoresObj[0].dominio !=''">
                                <i class="fa fa-edit text-primary" @click="editRow()"></i>
                            </td>
                        </tr>
                    </tbody>
                    <tbody role="rowgroup" v-if="editAutomotor"> 
                        <tr aria-rowindex="1" role="row" v-for="(automotor) in automotoresObj" :key="automotor.dominio">
                            <td aria-colindex="1" data-label="Tipo" role="cell" class="">
                                <b-form-select v-model="automotor.tipo" :options="options" class="form-control-sm" aria-selected="automotor"/>
                            </td>
                            <td aria-colindex="2" data-label="Dominio" role="cell" class="" >
                                <input v-model="automotor.dominio" class="form-control-plaintext" readOnly>
                            </td>
                            <td aria-colindex="3" data-label="Modelo" role="cell" class="">
                                <input v-model="automotor.modelo" class="form-control-sm">
                            </td>
                            <td aria-colindex="4" data-label="A&ntilde;o" role="cell" class="">
                                <input v-model="automotor.anio" :readOnly="!editAutomotor" class="form-control-sm">
                            </td>
                            <td aria-colindex="5" data-label="Valuaci&oacute;n DNRPCP" role="cell" class="">
                                <input v-model="automotor.valuacion" class="form-control-plaintext" readOnly>
                            </td>
                            <td aria-colindex="6" data-label="edit" role="cell" class="" v-if="automotoresObj[0].dominio !=''">
                                <i class="fa fa-edit text-primary" @click="editRow()"></i>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-1">
                <i class="fa fa-file fa-2x"></i>
            </div>
            <div class="col-11">
                <h4 aria-describedby="title-1"><b>Datos de la transferencia</b></h4>
                <form>
                    <div class="form-group form-inline">
                        <label for="input_2"><b>Valor total del bien a transferir&nbsp;</b></label>
                        <input type="text" name="Valor total" class="form-control-sm col-2" aria-describedby="input_2" v-model="automotoresObj[0].valor">
                    </div>
                    <div class="checkbox-inline">
                        <label for="check-1">Transfiero el Vehiculo a una compañia de seguros&nbsp;</label>
                        <input type="checkbox" id="check-1" v-model="automotoresObj[0].isTransferSeguro">
                    </div>
                </form>
            </div>
        </div>
    </section>
</template>

<script>
    import { mapMutations } from 'vuex'
    import { mapState } from 'vuex'
    import AwesomeMask from 'awesome-mask'
    import resConsulta from '../data/automotores.json'
    import options from '../data/options.json'

    export default {
        // props: ["step", "currentstep"],
        data(){
            return{
                dominio:"",
                editAutomotor:false,
                automotoresObj:[{
                    tipo:"",
                    modelo:"",
                    dominio: "",
                    valuacion: "",
                    anio: "",
                    valor: "",
                    isTransferSeguro : false
                }],
                selected: null,
                options: options,
                automotores:resConsulta,
            }
        },
        computed:{
            setCurrentTPage(){
                setCurrentPage();
            }
        },
        directives: {
            'mask': AwesomeMask
        },
        methods: {
            ...mapMutations([
                'clearAutomotor',
                'setAutomotor',
                'setContinuar',
                'setCurrentPage'
                , 'setContinuar'
            ]),
            /*setContinuar(){
                if(this.automotoresObj.length!=0){
                    //setContinuar();
                    this.setContinuar(true);
                }
            },*/
            clearMyAutomotor(){
                this.search();
                this.clearAutomotor();
                this.automotoresObj= [{
                        tipo:"",
                        modelo:"",
                        dominio: "",
                        valuacion: "",
                        anio: "",
                        valor: "",
                        isTransferSeguro : false
                    }];
            },
            setMyAutomotor(){
                this.search();
                this.setAutomotor(this.automotoresObj[0]);
                this.setContinuar(false);
                
            },
            search(){
                if(this.dominio!=""){
                    this.automotoresObj= this.automotores.filter(auto => {
                        return auto.dominio.toLowerCase().includes(this.dominio.toLowerCase())
                    });
                } else {
                    this.automotoresObj= [{
                        tipo:"",
                        modelo:"",
                        dominio: "",
                        valuacion: "",
                        anio: "",
                        valor: "",
                        isTransferSeguro : false
                    }];
                }
            },
            setCurrentPage(){
                setCurrentPage("Datos de el Automotor");
            },
            editRow(){
                this.editAutomotor = !this.editAutomotor;
            } 
        }
    }
</script>
