<template>
    <section>
        <div class="card col-md-6 mx-3 mb-3 pl-0" v-for="(user, index) in mapuser" :key="user.cuit">
            <div class="card-header">
                <div>
                    <input type="checkbox" id="check-1" >
                </div>
                <div class="col-md-1">
                    <button type="button" class="btn tacho mr-5" @click="removeRow(index)">
                        <i class="fa fa-trash fa-1x inverted"></i>
                    </button>
                </div>

            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-1 align-self-center">
                        <i class="text-primary thumbnail fa fa-user fa-2x"></i>
                    </div>
                    <div class="col-md-10">
                        <h6>
                            <b>{{ user.name }}</b>  
                            ({{ user.cuit | toCuit }})&nbsp;&nbsp;                                        
                        </h6>
                        <!-- <input type="checkbox" id="check-1" v-model="<variable>"> -->
                        <div class="h2color" >
                            <label class="h2color">Porcentaje de Titularidad</label> 
                            <input :value="user.titularidad" style="width: 5%; color:black" class="h2color" > %
                            <label class="h2color">  Porcentaje de Transferencia  </label>
                            <input type="text" style="width: 5%; color:black" id="tooltipButton-index" class="h2color" v-model="user.transferencia"> %
                            <b-tooltip  target="tooltipButton-2" >{{message}}</b-tooltip>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>
