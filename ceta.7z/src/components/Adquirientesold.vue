 <template>      
    <div class="form-group">        
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-6 .col-md-2" >
                    <i :class="'fa fa-user fa-2x'"></i>
                </div>
                <div class="col-sm-9 mb-3" >
                    <h5 aria-describedby="title-ident"><b>Identificaci&oacute;n</b></h5>
                    <small id="title-ident" class="form-text text-muted">Ingres&aacute; los datos de los adquirientes.</small>
                </div>  
                <div class="mx-5 mb-2" v-show="validated2 ==  0">
                    <div class="form-group form-inline">
                        <label for="text-cuil"><b>CUIT/CUIL/CDI</b></label>&nbsp;&nbsp;
                        <input type="text" class="form-input col-6" v-model.trim.lazy="$v.buscador.$model" 
                           :disabled="validated == 1" v-mask="'99-99999999-9'" >
                    </div>
                </div>
            </div> 
            <div class="row" v-show="validated2 ==  0">
                <div class="col-sm-3"></div>
                <div class="col-sm-6 mb-3">
                    <button type="button"  :class="icon_btn1" class="btn" @click="search" 
                    :disabled="validated == 1 && validated2==1" style="font-size: 12px;">CONFIRMAR</button>
                </div>
            </div>
            <div class="row">
                <div class="list-group mx-3 mb-3" >
                    <div v-for="(user, index) in mapAdqui" :key="user.cuit">
                        <div class="card" style="width: 40rem;">                                     
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-1 align-self-center">
                                        <i class="text-primary thumbnail fa fa-user fa-2x"></i>
                                    </div>
                                    <div class="col-md-10">
                                        <h6 ><b>{{ user.name }}</b> ({{ user.cuit | toCuit }})  </h6>
                                        <div class="h2color" >
                                            <label class="h2color">Porcentaje de Titularidad</label> 
                                            <input :value="user.titularidad" style="width: 5%; color:black" class="h2color" > %
                                            <label class="h2color">  Porcentaje de Transferencia  </label>
                                            <input type="text" style="width: 5%; color:black" id="tooltipButton-2" class="h2color" v-model="user.transferencia"> %
                                            <b-tooltip target="tooltipButton-2" >{{message}}</b-tooltip>
                                        </div>  
                                    </div>
                                    <div class="col-md-1">
                                        <button type="button" class="btn tacho mr-5" @click="removeRow(index)">
                                            <i class="fa fa-trash fa-1x inverted"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>  
                        </div>     
                    </div>
                </div>
            </div>
            <div class="row" style="margin-left: 407px; ceta-Leyenda">
                <button type="button" class="btn" 
                style="font-size: 12px;"  v-show="checkBtn" @click="agregarTransferentes"
                :disabled="validarBtnAgregar == 1 " :class="icon_btn2">
                <b>AGREGAR ADQUIRIENTE </b></button>
            </div> 
            <!--div class="card bg-warning text-white mt-3" style="width: 603px;" v-show="validated2==1">                                              
                <div class="card-body leyenda" >
                    <label class="h2colorText">{{message2}}</label>
                    <form class="form-inline">
                        <input class="form-control col-sm-6">
                        <button type="button" class="btn btn-primary ml-2">CONFIRMAR</button>
                    </form>
                </div>      
            </div-->  
            <br/>  
            <div class="row h2colorText" style="margin-left: 105px; font-size: 16px;"  v-show="checkBtn">
                <b>Porcentaje total del bien transferido {{total}}%</b>
            </div>      
        </div>
    </div>
</template> 



<script>
  import { mapMutations } from 'vuex'
  import AwesomeMask from 'awesome-mask'
  import {mayorQcero, buscarCuitEnMap} from './helpers.js'
  import resConsulta from '../data/users.json'
  import { minLength , maxLength, numeric, email } from 'vuelidate/lib/validators'

  export default {
     name: 'Resultado',
	data() {
      return{ 
        message: "Del 100% del automotor, ¿qué porcentaje vas a transferir? recordá que no puedes superar tu porcentaje de titularidad",
        message2: "Te recordamos que al seleccionar a este adquiriente como emisor del certificado, será quien pueda realizar la consulta del mismo a traves del servicio."+
                    "A continuacion, indicanos el correo electrónico para que podamos informárselo.",
        buscador: '',  
        mapAdqui: [],
        usersFilter: [],
        validated:0,
        validated2:0,
        totalTransferencia:0,
        users: resConsulta
      }
        },
        directives: {
        'mask': AwesomeMask
    },
    
    validations: {
        buscador: {    
            minLength: minLength(13), 
            maxLength: maxLength(13), 
            mayorQcero
        }
    },

		methods: {
			stepChanged(step) {
				this.currentstep = step;
            },
            ...mapMutations([
                'addAdquiriente', 'removeAdquiriente'
            ]),
            search(){
                if(this.buscador!=""){
                    this.usersFilter= buscarCuitEnMap(this.buscador, this.users);
                    if(this.usersFilter.length>0){
                        if(this.geListAdquirientes.length>0){
                        this.mapAdqui = this.geListAdquirientes;
                        } else {
                            this.mapAdqui= [];
                        }
                        var userExist = buscarCuitEnMap(this.buscador, this.mapAdqui)
                        if(userExist.length<1){
                            this.addAdquiriente(this.usersFilter[0]);
                            this.mapAdqui = this.geListAdquirientes;
                        }                            
                                           
                        this.validated=1;
                        this.buscador="";
                    }    
                }
                
            },
            removeRow(index){
                var accepted = confirm('¿Estas seguro que deseas eliminar este Adquiriente?.');
                if(accepted) {
                    this.mapAdqui.splice(index,1); 
                    this.removeAdquiriente(index);
                    if(this.mapAdqui.length==0)
                        this.validated=0;
                }                
            },
            agregarTransferentes(){
                this.validated=0;
                this.validated2=0;
            }
        },
        computed:{
            icon_btn1(){
                return this.validated==0?"btn-primary":"btn-secondary";
            },
            icon_btn2(){
                return this.validated==1 && this.validated2==0?"btn-primary":"btn-secondary";
            },
            checkBtn(){
                let lengthUsers = this.mapAdqui.length;
                return lengthUsers>0?true:false;
            },
            total: function(){
                this.totalTransferencia= this.mapAdqui.reduce(
                    function(total, user){
                        return parseInt(total) + parseInt(user.transferencia); 
                    },0);
                return this.totalTransferencia;
            },
            validarBtnAgregar: function(){
                this.validated2=this.totalTransferencia>=100?1:0;
                this.totalTransferencia==100?true:false;
                return this.validated2;
            }
            ,geListAdquirientes() {
                return this.$store.getters.adquirientes
            }

        }
	}
</script>


