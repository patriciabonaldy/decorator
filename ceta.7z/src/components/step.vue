<template>
	<div class="step-wrapper float-right" :class="stepWrapperClass">
		<button type="button" class="btn btn-primary" @click="lastStep" :hidden="firststep">
			Volver
		</button>
		<button type="button" class="btn btn-primary" @click="nextStep" :hidden="laststep" :disabled="continuar">
			Continuar
		</button>
		<router-link  class="btn btn-primary" v-if="laststep" :to="'congrats'"  v-on:click.native="finalizar">
			Continuar
		</router-link>
	</div>
</template>
<script>
	import { mapState } from 'vuex';
	import { mapMutations } from 'vuex';

	export default {
		name:"step",
		props: ["step", "stepcount", "currentstep"],

		computed: {
			...mapState([
            'continuar'
        	]),
			active() {
				return this.step.id == this.currentstep;
			},

			firststep() {
				return this.currentstep == 1;
			},

			laststep() {
				return this.currentstep == this.stepcount;
			},

			stepWrapperClass() {
				return {
					active: this.active
				};
			},
			getContinuar() {
				return this.$store.getters.continuar
			}
		},

		methods: {
			...mapMutations([
           		'setCurrentPage'
        	]),
			nextStep() {
				this.setCurrentPage(this.currentstep);
				this.$emit("step-change", this.currentstep + 1);
			},

			lastStep() {
				this.setCurrentPage(this.currentstep);
				this.$emit("step-change", this.currentstep - 1);
			},

			finalizar(){
				this.setCurrentPage(4);
			}
		}
	}
</script>
