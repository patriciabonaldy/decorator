 <template>   
    <section>   
        <div class="row">
            <div class="col-md-1 .col-md-2" >
                <i :class="'fa fa-user fa-2x'"></i>
            </div>
            <div class="col-md-11 mb-4" >
                <h4 aria-describedby="title-2" ><b>Identificaci&oacute;n</b></h4>
                <small id="title-2" class="form-text text-muted mb-4">Ingres&aacute; los datos de los transferentes.</small>
                <form class="form-inline mx-4 mb-5">
                    <div class="form-group">
                        <label for="text-cuil"><b>CUIT/CUIL/CDI</b></label>&nbsp;&nbsp;
                        <input id="text-cuil" type="text" class="form-control-sm col-6" v-model.trim.lazy="$v.buscador.$model" :disabled="validated == 1" v-mask="'99-99999999-9'" >
                        <span class="alert alert-danger" v-if="!$v.buscador.minLength">Debe tener 11 digitos.</span>
                        <span class="alert alert-danger" v-if="!$v.buscador.maxLength">Debe tener 11 digitos.</span>
                        <span class="alert alert-danger" v-if="!$v.buscador.mayorQcero">No debe comenzar con cero.</span>
                    </div>
                    <button type="button" :class="icon_btn1" class="btn" @click="search" :disabled="validated == 1 && validated2==1" style="font-size: 12px;">CONFIRMAR</button>
                </form>
                <div class="card col-md-6 mx-3 mb-3 pl-0" style="width: 603px;" v-for="(user, index) in geListTransferentes" :key="user.cuit">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-1 align-self-center">
                                <i class="text-primary thumbnail fa fa-user fa-2x"></i>
                            </div>
                            <div class="col-md-10">
                                <h6><b>{{ user.name }}</b>({{ user.cuit | toCuit }})&nbsp;&nbsp;</h6>
                                <div class="h2color" >
                                    <label class="h2color">Porcentaje de Titularidad</label> 
                                    <input :value="user.titularidad" style="width: 5%; color:black" class="h2color" > %
                                    <label class="h2color">  Porcentaje de Transferencia  </label>
                                    <input type="text" 
                                        style="width: 5%; color:black"
                                        class="h2color" 
                                        v-model="user.transferencia"
                                        @blur="verificarTransferencia(index)"
                                        v-b-tooltip.hover :title=message> %
                                </div>
                                <div class="alert alert-danger" style="display: none;" v-bind:id="'errorTransfer'+index">
                                    {{errorTransferencia}}.
                                </div>
                                <input type="checkbox" id="check-1" >
                                <label class="h2color"> Establecer como principal  </label>
                                <br>
                            </div>
                            <div class="col-md-1">
                                <button type="button" class="btn tacho mr-5" @click="removeRow(index)">
                                    <i class="fa fa-trash fa-1x inverted"></i>
                                </button>
                            </div>  
                        </div>     
                    </div>
                </div>
                <div class="row" style="margin-left: 407px; ceta-Leyenda">
                    <button type="button" class="btn" 
                    style="font-size: 12px;"  v-show="checkBtn" @click="agregarTransferentes"
                    :disabled="validarBtnAgregar == 1 " :class="icon_btn2">
                    <b>AGREGAR TRANSFERENTE </b></button>
                </div> 
                <div class="card bg-warning mt-3" style="width: 603px;" v-show="validated2==1">                                              
                    <div class="card-body leyenda" >
                        <label class="h2colorText">{{message2}}</label>
                        <form class="form-inline">
                            <input class="form-control-sm col-sm-6">
                            <button type="button" class="btn btn-primary ml-2">CONFIRMAR</button>
                        </form>
                    </div>      
                </div>  
                <br/>  
                <div class="row h2colorText" style="margin-left: 105px; font-size: 16px;"  v-show="checkBtn">
                    <b>Porcentaje total del bien transferido {{total}}%</b>
                </div>      
            </div>
        </div>
    </section>
</template> 

<script>
  import { mapMutations } from 'vuex'
  import AwesomeMask from 'awesome-mask'
  import {mayorQcero, buscarCuitEnMap,countInvalidadosInMap} from './helpers.js'
  import resConsulta from '../data/users.json'

  import { minLength , maxLength, numeric, email } from 'vuelidate/lib/validators'


  export default {
     name: 'Resultado',
	data() {
      return {  
        message: "Del 100% del automotor, ¿qué porcentaje vas a transferir? recordá que no puedes superar tu porcentaje de titularidad",
        message2: "Te recordamos que al seleccionar a este adquiriente como emisor del certificado, será quien pueda realizar la consulta del mismo a traves del servicio."+
                    "A continuacion, indicanos el correo electrónico para que podamos informárselo.",
        errorTransferencia:"Porcentaje de Transferencia, no debe ser mayor al de Titularidad",
        buscador: '', 
        usersFilter: [],
        validated:0,
        validated2:0,
        totalTransferencia:0,
        users: resConsulta,
        valorMaximo: 0    ,
        itemUser: []    
      }
    },
    directives: {
        'mask': AwesomeMask
    },    
    validations: {
        buscador: {    
            minLength: minLength(13), 
            maxLength: maxLength(13), 
            mayorQcero//: this.$helpers.mayorQcero(buscador)
        }
    },
    methods: {        
        stepChanged(step) {
            this.currentstep = step;
        },
        ...mapMutations([
            'addTransferente', 'removeTransferente', 'setContinuar'
        ]),
        search(){
            if(this.buscador!=""){
                this.usersFilter= buscarCuitEnMap(this.buscador, this.users);
                if(this.usersFilter.length>0){
                    var userExist = buscarCuitEnMap(this.buscador, 
                                    this.geListTransferentes);
                    if(userExist.length<1){
                        this.addTransferente(this.usersFilter[0]);
                    }                
                    this.validated=1;
                    this.buscador="";
                }                
            }
            
        },
        removeRow(index){
            var accepted = confirm('¿Estas seguro que deseas eliminar este Transferente?');
            if(accepted) {
                this.removeTransferente(index);
                if(this.geListTransferentes.length==0)
                    this.validated=0;
            }                
        },
        agregarTransferentes(){
            this.validated=0;
            this.validated2=0;
        }
        ,verificarTransferencia: function(x){
            /*let index = this.mapuser[x].transferencia;
            let dup_array = this.mapuser.slice();
            dup_array.splice(x, 1);
            let totalSinActual= dup_array.reduce(
                                function(total, user){
                                    return parseInt(total) + parseInt(user.transferencia); 
                            },0);
            this.valorMaximo = 100-totalSinActual;
            if(index>100){
                if(index>this.valorMaximo){
                    this.isInvalido = true;
                }
            }*/
            
            if(this.geListTransferentes[x].transferencia > this.geListTransferentes[x].titularidad){
               this.geListTransferentes[x].invalido = true;
                document.getElementById("errorTransfer"+x).style.display = null;
            } else {
                this.geListTransferentes[x].invalido = false;
                document.getElementById("errorTransfer"+x).style.display ='none';
            }  
             
            let cantidad = countInvalidadosInMap(this.geListTransferentes);
            if(cantidad>0){
                this.setContinuar(true);
            } else {
                this.setContinuar(false);
            }              
                
        }
    },
    
    computed:{
        icon_btn1(){
            return this.validated==0?"btn-primary":"btn-secondary";
        },
        icon_btn2(){
            return this.validated==1 && this.validated2==0?"btn-primary":"btn-secondary";
        },
        checkBtn(){
            let lengthUsers = this.geListTransferentes.length;
            return lengthUsers>0?true:false;
        },
        checkTransfer: function(value){
            return value;
        },        
        total: function(){
            this.totalTransferencia= this.geListTransferentes.reduce(
                function(total, user){
                    return parseInt(total) + parseInt(user.transferencia); 
                },0);
            return this.totalTransferencia;
        },        
        validarBtnAgregar: function(){
            this.validated2=this.totalTransferencia>=100?1:0;
            this.totalTransferencia==100?true:false;
            return this.validated2;
        }
        ,geListTransferentes() {
            return this.$store.getters.transferentes
        }
        
        
    }
	}
</script>


