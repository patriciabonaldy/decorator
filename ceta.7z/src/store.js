import Vue from 'vue'
import Vuex from 'vuex'
import { getField, updateField } from 'vuex-map-fields';

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    subtitulo: 'ceta',
    version: '#',
    stepname: "",
    transferentes:[],
    adquirientes:[],
    automotor:{
        tipo:"",
        modelo:"",
        dominio: "",
        valuacion: "",
        anio: "",
        valor: "",
        isTransferSeguro: false
    },
    automotores:[{
      tipo:"",
      modelo:"",
      dominio: "",
      valuacion: "",
      anio: "",
      valor: ""
    }],
    emailContacto:"",
    continuar:false,
    currentstep: 1,
    currentPage: 0,
    steps: [{
        id: 1,
        title: "Automotores",
        icon_class: ""
      },
      {
        id: 2,
        title: "Transferentes",
        icon_class: ""
      },
      {
        id: 3,
        title: "Adquirientes",
        icon_class: ""
      },
      {
        id: 4,
        title: "Confirmación",
        icon_class: ""
      }
    ]
  },
  actions:{
    setAutomotor(context, automotor) {
        context.commit("setAutomotor", automotor)
    },
    addTransferente(context, transferente) {
      context.commit("addTransferente", transferente)
    },
    removeTransferente(context, index) {
      context.commit("removeTransferente", index)
    },
    addAdquiriente(context, adquiriente) {
      context.commit("addAdquiriente", adquiriente)
    },
    removeAdquiriente(context, index) {
      context.commit("removeAdquiriente", index)
    },
    setContinuar(context, continuar){
      context.commit("setContinuar", continuar)
    }

  },
  mutations: {
    
    addTransferente(state, transferente) {
      state.transferentes.push(transferente);
    },
    addAdquiriente(state, adquiriente) {
      state.adquirientes.push(adquiriente);
    },
    setAutomotor(state, automotor){
      state.automotor = automotor;
    },
    addAutomotores(state, automotor) {
      state.automotores.push(automotor);
    },
    clearAutomotor(){
      this.state.automotor = {
        tipo:"",
        modelo:"",
        dominio: "",
        valuacion: "",
        anio: "",
        valor: "",
        isTransferSeguro: false
      };
    },
    removeTransferente(state, index){
      if (index > -1) {
        state.transferentes.splice(index, 1);
      }
    },
    removeAdquiriente(state, index){
      if (index > -1) {
        state.adquirientes.splice(index, 1);
      }
    },
    setCurrentstep(state,step){
      state.currentstep = step;
    },
    setContinuar(state, continuar){
      state.continuar=/*!state.*/continuar;
    },
    setCurrentPage(state,title){
      state.currentPage=title;
    },
    updateField,
  },
  getters: {
    getField,
    transferentes: state => state.transferentes,
    adquirientes: state => state.adquirientes,
    continuar: state => state.continuar
  },
})
